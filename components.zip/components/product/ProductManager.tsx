"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";

type ProductSku = {
  id: number;
  sku: string;
  color: string;
  size: string;
  stock: number;
};

type Supplier = {
  id: number;
  code: string;
  name: string;
};

type Product = {
  id: number;
  code: string;
  name: string;
  brand: string | null;
  category: string | null;
  colors: string | null;
  sizes: string | null;
  cost: number | null;
  cost2: number | null;
  cost3: number | null;
  price: number | null;
  imageUrl: string | null;
  productType: "DIRECT" | "BROKER";
  sourceProductName: string | null;
  bandPostId: string | null;
  bandPostUrl: string | null;
  isBandImported: boolean;
  supplierId: number | null;
  supplier: Supplier | null;
  supplier2Id: number | null;
  supplier2: Supplier | null;
  supplier3Id: number | null;
  supplier3: Supplier | null;
  skus: ProductSku[];
};

type ProductExcelRow = {
  상품코드?: unknown;
  상품명?: unknown;
  공급업체?: unknown;
  단가?: unknown;
  색상?: unknown;
  사이즈?: unknown;
  판매가?: unknown;
  브랜드?: unknown;
  카테고리?: unknown;
  이미지URL?: unknown;
  상품유형?: unknown;
};

function excelText(value: unknown) {
  return value === null || value === undefined ? "" : String(value).trim();
}

function excelNumber(value: unknown) {
  const text = excelText(value).replace(/,/g, "");
  if (!text) return "";
  const number = Number(text);
  return Number.isFinite(number)
    ? String(Math.round(number * 10) / 10)
    : "";
}

function supplierCodeFromProductCode(productCode: string) {
  const matched = productCode
    .trim()
    .toUpperCase()
    .match(/^([A-Z]{2})/);

  return matched?.[1] || "";
}

type ParsedBandPost = {
  code: string;
  sourceProductName: string;
  colors: string;
  sizes: string;
};

function cleanBandLine(value: string) {
  return value
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/^[\s✔️✅☑️•·▪︎◾◼︎■◆◇▶▷➤➜⛳️-]+/, "")
    .trim();
}

function normalizeProductCode(value: string) {
  return value
    .toUpperCase()
    .replace(/\s+/g, "")
    .trim();
}

function parseBandPost(text: string): ParsedBandPost | null {
  const rawLines = text.replace(/\r/g, "").split("\n");
  const lines = rawLines.map(cleanBandLine);
  const meaningful = lines.filter(Boolean);

  if (meaningful.length < 2) return null;

  const codePattern = /^([A-Z]{1,3})\s*[-_]?\s*(\d{4,})$/i;

  const codeCandidates = meaningful
    .map((line, index) => ({
      line,
      index,
      match: line.match(codePattern),
    }))
    .filter((item) => item.match);

  if (codeCandidates.length === 0) return null;

  const selectedCode = codeCandidates[codeCandidates.length - 1];

  const code = normalizeProductCode(selectedCode.line);

  const firstCodeIndex = codeCandidates[0].index;

  let sourceProductName = "";

  for (
    let index = firstCodeIndex + 1;
    index < meaningful.length;
    index += 1
  ) {
    const line = meaningful[index];
    const upper = line.toUpperCase();

    if (codePattern.test(line)) continue;

    if (
      /^(COLOR|COLOUR|색상|SIZE|사이즈|매장가|판매가|PRICE|바배)\s*[:：]?/i.test(
        line
      )
    )
      continue;

    if (/^\(?\d+\s*켤레/i.test(line)) continue;

    if (/^[0-9]+(?:\.[0-9]+)?$/.test(line)) continue;

    if (
      upper.startsWith("HTTP://") ||
      upper.startsWith("HTTPS://")
    )
      continue;

    sourceProductName = line;
    break;
  }
    }

  function extractLabelValue(labelPattern: RegExp) {
    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const match = line.match(labelPattern);

      if (!match) continue;

      const values: string[] = [];

      const inlineValue = (match[1] || "").trim();

      if (inlineValue) {
        values.push(inlineValue);
      }

      for (
        let nextIndex = index + 1;
        nextIndex < lines.length;
        nextIndex += 1
      ) {
        const next = lines[nextIndex].trim();

        if (!next) {
          if (values.length > 0) break;
          continue;
        }

        if (
          /^(COLOR|COLOUR|색상|SIZE|사이즈|매장가|판매가|PRICE)\s*[:：]?/i.test(
            next
          )
        ) {
          break;
        }

        if (
          codePattern.test(next) ||
          /^[0-9]+(?:\.[0-9]+)?$/.test(next)
        ) {
          break;
        }

        if (
          next.startsWith("-") ||
          next.startsWith("•")
        ) {
          break;
        }

        values.push(next);

        if (values.length >= 2) {
          break;
        }
      }

      return values
        .join(" ")
        .replace(/\s*,\s*/g, ", ")
        .trim();
    }

    return "";
  }

  const colors = extractLabelValue(
    /^(?:COLOR|COLOUR|색상)\s*[:：]\s*(.*)$/i
  );

  const sizes = extractLabelValue(
    /^(?:SIZE|사이즈)\s*[:：]\s*(.*)$/i
  );

  if (!sourceProductName) {
    return null;
  }

  return {
    code,
    sourceProductName,
    colors,
    sizes,
  };
}

type ProductForm = {
  code: string;
  name: string;
  brand: string;
  category: string;
  colors: string;
  sizes: string;
  cost: string;
  cost2: string;
  cost3: string;
  price: string;
  imageUrl: string;
  productType: "DIRECT" | "BROKER";
  supplierId: string;
  supplier2Id: string;
  supplier3Id: string;
  sourceProductName: string;
  bandPostId: string;
  bandPostUrl: string;
  isBandImported: boolean;
};

const emptyForm: ProductForm = {
  code: "",
  name: "",
  brand: "",
  category: "",
  colors: "",
  sizes: "",
  cost: "",
  cost2: "",
  cost3: "",
  price: "",
  imageUrl: "",
  productType: "DIRECT",
  supplierId: "",
  supplier2Id: "",
  supplier3Id: "",
  sourceProductName: "",
  bandPostId: "",
  bandPostUrl: "",
  isBandImported: false,
};

function normalizeOneDecimal(value: string) {
  const cleaned = value
    .replace(/,/g, "")
    .replace(/[^0-9.]/g, "")
    .replace(/(\..*)\./g, "$1");

  const [integerPart = "", decimalPart] = cleaned.split(".");

  return decimalPart !== undefined
    ? `${integerPart}.${decimalPart.slice(0, 1)}`
    : integerPart;
}

export default function ProductManager() {
  const [products, setProducts] = useState<Product[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [form, setForm] = useState<ProductForm>(emptyForm);
  const [bandPostText, setBandPostText] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [showProductForm, setShowProductForm] = useState(false);
  const [openedProductIds, setOpenedProductIds] = useState<number[]>([]);
  const [openedMobileProductIds, setOpenedMobileProductIds] = useState<number[]>([]);
  const [search, setSearch] = useState("");
  const [searchField, setSearchField] = useState("all");
  const [saving, setSaving] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [isDraggingImage, setIsDraggingImage] = useState(false);
  const [uploadingProductImageId, setUploadingProductImageId] = useState<number | null>(null);
  const [focusedProductImageId, setFocusedProductImageId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [inlineSupplierDrafts, setInlineSupplierDrafts] = useState<Record<number, string>>({});
  const [inlineCostDrafts, setInlineCostDrafts] = useState<Record<number, string>>({});
  const [inlineSavingId, setInlineSavingId] = useState<number | null>(null);
  const [importingExcel, setImportingExcel] = useState(false);

  const excelInputRef = useRef<HTMLInputElement | null>(null);
    async function loadProducts() {
    try {
      const response = await fetch("/api/product", {
        cache: "no-store",
      });

      if (!response.ok) {
        throw new Error("상품 조회 실패");
      }

      const data = await response.json();

      setProducts(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
      alert("상품 목록을 불러오지 못했습니다.");
    }
  }

  async function loadSuppliers() {
    try {
      const response = await fetch("/api/suppliers", {
        cache: "no-store",
      });

      if (!response.ok) {
        throw new Error("공급업체 조회 실패");
      }

      const data = await response.json();

      setSuppliers(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(error);
      setSuppliers([]);
    }
  }

  function downloadProductExcel() {
    const rows = products.length
      ? products.map((product) => ({
          상품코드: product.code,
          상품명: product.name,
          공급업체: product.supplier?.name || "",
          단가: product.cost ?? "",
          색상: product.colors || "",
          사이즈: product.sizes || "",
          판매가: product.price ?? "",
          브랜드: product.brand || "",
          카테고리: product.category || "",
          이미지URL: product.imageUrl || "",
          상품유형:
            product.productType === "BROKER"
              ? "중도매"
              : "직접",
        }))
      : [
          {
            상품코드: "A0001",
            상품명: "예시 상품",
            공급업체: "예시 공급업체",
            단가: 1.5,
            색상: "블랙,화이트",
            사이즈: "M,L,XL",
            판매가: "",
            브랜드: "",
            카테고리: "",
            이미지URL: "",
            상품유형: "직접",
          },
        ];

    const guideRows = [
      {
        항목: "필수",
        설명: "상품코드, 상품명",
      },
      {
        항목: "선택 항목",
        설명:
          "공급업체, 단가, 색상, 사이즈 등 나머지 컬럼은 없어도 등록됩니다.",
      },
      {
        항목: "기본값",
        설명:
          "공급업체·색상·사이즈는 빈칸, 단가는 0으로 등록되며 상품관리에서 수정할 수 있습니다.",
      },
      {
        항목: "공급업체",
        설명:
          "기존 업체명 또는 업체코드를 입력합니다. 없는 업체는 자동 등록됩니다.",
      },
      {
        항목: "상품유형",
        설명:
          "직접 또는 중도매를 입력합니다. 비워두면 직접으로 등록됩니다.",
      },
      {
        항목: "재업로드",
        설명:
          "같은 상품코드가 있으면 해당 상품을 수정하고, 없으면 새 상품으로 등록합니다.",
      },
    ];

    const workbook = XLSX.utils.book_new();

    const productSheet =
      XLSX.utils.json_to_sheet(rows);

    const guideSheet =
      XLSX.utils.json_to_sheet(guideRows);

    productSheet["!cols"] = [
      { wch: 16 },
      { wch: 30 },
      { wch: 18 },
      { wch: 10 },
      { wch: 22 },
      { wch: 22 },
      { wch: 10 },
      { wch: 16 },
      { wch: 16 },
      { wch: 40 },
      { wch: 12 },
    ];

    guideSheet["!cols"] = [
      { wch: 16 },
      { wch: 80 },
    ];

    XLSX.utils.book_append_sheet(
      workbook,
      productSheet,
      "상품목록"
    );

    XLSX.utils.book_append_sheet(
      workbook,
      guideSheet,
      "작성방법"
    );

    XLSX.writeFile(
      workbook,
      "상품등록_양식.xlsx"
    );
  }

  async function findOrCreateSupplierId(
    nameOrCode: string
  ) {
    const keyword = nameOrCode.trim();

    if (!keyword) return "";

    const matched = suppliers.find(
      (supplier) =>
        supplier.name
          .trim()
          .toLowerCase() ===
          keyword.toLowerCase() ||
        supplier.code
          .trim()
          .toLowerCase() ===
          keyword.toLowerCase()
    );

    if (matched) {
      return String(matched.id);
    }

    const response = await fetch(
      "/api/suppliers",
      {
        method: "POST",
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify({
          code: keyword,
          name: keyword,
          businessNumber: "",
          representative: "",
          phone: "",
          email: "",
          address: "",
          contactName: "",
          contactPhone: "",
          bankName: "",
          bankAccount: "",
          accountHolder: "",
          memo: "",
        }),
      }
    );

    const result = await response.json();

    if (!response.ok) {
      throw new Error(
        result.message ||
          `${keyword} 공급업체 등록 실패`
      );
    }

    return String(result.id);
  }
    async function uploadProductExcel(
    event: React.ChangeEvent<HTMLInputElement>
  ) {
    const file = event.target.files?.[0];
    event.target.value = "";

    if (!file) return;

    try {
      setImportingExcel(true);

      const data = await file.arrayBuffer();

      const workbook = XLSX.read(data, {
        type: "array",
      });

      const firstSheet =
        workbook.Sheets[workbook.SheetNames[0]];

      const rows =
        XLSX.utils.sheet_to_json<ProductExcelRow>(
          firstSheet,
          {
            defval: "",
          }
        );

      if (rows.length === 0) {
        alert("엑셀에 등록할 상품이 없습니다.");
        return;
      }

      const validRows = rows.filter(
        (row) =>
          excelText(row.상품코드) ||
          excelText(row.상품명)
      );

      const errors: string[] = [];

      validRows.forEach((row, index) => {
        const missing = [
          ["상품코드", excelText(row.상품코드)],
          ["상품명", excelText(row.상품명)],
        ]
          .filter(([, value]) => !value)
          .map(([label]) => label);

        if (missing.length) {
          errors.push(
            `${index + 2}행: ${missing.join(
              ", "
            )} 누락`
          );
        }
      });

      if (errors.length) {
        alert(
          `엑셀 내용을 확인해주세요.\n\n${errors
            .slice(0, 10)
            .join("\n")}${
            errors.length > 10 ? "\n..." : ""
          }`
        );

        return;
      }

      const confirmed = window.confirm(
        `${validRows.length}개 상품을 업로드합니다.\n같은 상품코드는 기존 상품을 수정합니다. 진행할까요?`
      );

      if (!confirmed) return;

      const supplierCache = new Map<
        string,
        string
      >();

      const productMap = new Map(
        products.map((product) => [
          product.code
            .trim()
            .toLowerCase(),
          product,
        ])
      );

      let created = 0;
      let updated = 0;

      const failed: string[] = [];

      for (
        let index = 0;
        index < validRows.length;
        index += 1
      ) {
        const row = validRows[index];

        const code = excelText(row.상품코드);

        try {
          const supplierText =
            excelText(row.공급업체) ||
            supplierCodeFromProductCode(code);

          let supplierId = "";

          if (supplierText) {
            const cacheKey =
              supplierText.toLowerCase();

            supplierId =
              supplierCache.get(cacheKey) || "";

            if (!supplierId) {
              supplierId =
                await findOrCreateSupplierId(
                  supplierText
                );

              supplierCache.set(
                cacheKey,
                supplierId
              );
            }
          }

          const existing =
            productMap.get(
              code.toLowerCase()
            );

          const payload = {
            id: existing?.id,
            code,
            name: excelText(row.상품명),
            brand: excelText(row.브랜드),
            category: excelText(row.카테고리),
            colors: excelText(row.색상),
            sizes: excelText(row.사이즈),
            cost:
              excelNumber(row.단가) || "0",
            cost2:
              existing?.cost2 == null
                ? ""
                : String(existing.cost2),
            cost3:
              existing?.cost3 == null
                ? ""
                : String(existing.cost3),
            price: excelNumber(row.판매가),
            imageUrl: excelText(
              row.이미지URL
            ),
            productType:
              excelText(row.상품유형).includes(
                "중도매"
              )
                ? "BROKER"
                : "DIRECT",
            supplierId,
            supplier2Id:
              existing?.supplier2Id
                ? String(
                    existing.supplier2Id
                  )
                : "",
            supplier3Id:
              existing?.supplier3Id
                ? String(
                    existing.supplier3Id
                  )
                : "",
            sourceProductName:
              existing?.sourceProductName ||
              "",
            bandPostId:
              existing?.bandPostId || "",
            bandPostUrl:
              existing?.bandPostUrl || "",
            isBandImported: Boolean(
              existing?.isBandImported
            ),
            excelImport: true,
          };

          const response = await fetch(
            "/api/product",
            {
              method: existing
                ? "PUT"
                : "POST",
              headers: {
                "Content-Type":
                  "application/json",
              },
              body: JSON.stringify(
                payload
              ),
            }
          );

          const result =
            await response.json();

          if (!response.ok) {
            throw new Error(
              result.message ||
                "상품 저장 실패"
            );
          }

          if (existing) {
            updated += 1;
          } else {
            created += 1;

            productMap.set(
              code.toLowerCase(),
              result
            );
          }
        } catch (error) {
          failed.push(
            `${index + 2}행 ${code}: ${
              error instanceof Error
                ? error.message
                : "등록 실패"
            }`
          );
        }
      }

      await Promise.all([
        loadProducts(),
        loadSuppliers(),
      ]);

      alert(
        `엑셀 업로드가 완료되었습니다.\n신규 등록: ${created}개\n수정: ${updated}개\n실패: ${failed.length}개` +
          (failed.length
            ? `\n\n${failed
                .slice(0, 10)
                .join("\n")}`
            : "")
      );
    } catch (error) {
      console.error(error);

      alert(
        error instanceof Error
          ? error.message
          : "엑셀 업로드 중 오류가 발생했습니다."
      );
    } finally {
      setImportingExcel(false);
    }
  }
    async function loadCurrentUser() {
    try {
      const response = await fetch("/api/auth/me", {
        cache: "no-store",
      });

      if (!response.ok) {
        setIsAdmin(false);
        return;
      }

      const data = await response.json();

      setIsAdmin(data?.user?.role === "ADMIN");
    } catch {
      setIsAdmin(false);
    }
  }

  useEffect(() => {
    loadProducts();
    loadSuppliers();
    loadCurrentUser();
  }, []);

  const filteredProducts = useMemo(() => {
    const keyword = search.trim().toLowerCase();

    return products.filter((product) => {
      if (!keyword) {
        return true;
      }

      const fields: Record<string, unknown[]> = {
        all: [
          product.code,
          product.name,
          product.brand,
          product.category,
          product.colors,
          product.sizes,
          product.sourceProductName,
          product.supplier?.name,
          product.supplier2?.name,
          product.supplier3?.name,
        ],
        code: [product.code],
        name: [
          product.name,
          product.sourceProductName,
        ],
        supplier: [
          product.supplier?.name,
          product.supplier2?.name,
          product.supplier3?.name,
        ],
        brand: [product.brand],
        category: [product.category],
      };

      return (
        fields[searchField] || fields.all
      ).some((value) =>
        String(value || "")
          .toLowerCase()
          .includes(keyword)
      );
    });
  }, [products, search, searchField]);

  function resetForm() {
    setForm(emptyForm);
    setBandPostText("");
    setEditingId(null);
  }

  function openCreateForm() {
    if (showProductForm) {
      resetForm();
      setShowProductForm(false);
      return;
    }

    resetForm();
    setShowProductForm(true);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  function startEdit(product: Product) {
    setEditingId(product.id);

    setForm({
      code: product.code,
      name: product.name,
      brand: product.brand || "",
      category: product.category || "",
      colors: product.colors || "",
      sizes: product.sizes || "",
      cost: String(product.cost || ""),
      cost2: String(product.cost2 || ""),
      cost3: String(product.cost3 || ""),
      price: String(product.price || ""),
      imageUrl: product.imageUrl || "",
      productType: "DIRECT",
      supplierId: product.supplierId
        ? String(product.supplierId)
        : "",
      supplier2Id: product.supplier2Id
        ? String(product.supplier2Id)
        : "",
      supplier3Id: product.supplier3Id
        ? String(product.supplier3Id)
        : "",
      sourceProductName:
        product.sourceProductName || "",
      bandPostId: product.bandPostId || "",
      bandPostUrl: product.bandPostUrl || "",
      isBandImported: Boolean(
        product.isBandImported
      ),
    });

    setShowProductForm(true);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  function cancelForm() {
    resetForm();
    setShowProductForm(false);
  }

  function updateForm(
    field: keyof ProductForm,
    value: string | boolean
  ) {
    setForm((current) => {
      const next = {
        ...current,
        [field]: value,
      } as ProductForm;

      if (
        field === "code" &&
        typeof value === "string"
      ) {
        const supplierCode =
          supplierCodeFromProductCode(value);

        const matchedSupplier =
          suppliers.find(
            (supplier) =>
              supplier.code
                .trim()
                .toUpperCase() ===
              supplierCode
          );

        next.supplierId = matchedSupplier
          ? String(matchedSupplier.id)
          : "";
      }

      if (
        field === "sourceProductName" &&
        typeof value === "string"
      ) {
        next.name = value;
      }

      return next;
    });
  }

  function changePrimarySupplier(
    nextSupplierId: string
  ) {
    setForm((current) => {
      if (
        nextSupplierId ===
        current.supplier2Id
      ) {
        return {
          ...current,
          supplierId: current.supplier2Id,
          cost: current.cost2,
          supplier2Id: current.supplierId,
          cost2: current.cost,
        };
      }

      if (
        nextSupplierId ===
        current.supplier3Id
      ) {
        return {
          ...current,
          supplierId: current.supplier3Id,
          cost: current.cost3,
          supplier3Id: current.supplierId,
          cost3: current.cost,
        };
      }

      return {
        ...current,
        supplierId: nextSupplierId,
      };
    });
  }
    function isSupportedImage(file: File) {
    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/webp",
      "image/gif",
    ];

    if (!allowedTypes.includes(file.type)) {
      alert(
        "JPG, PNG, WEBP, GIF 이미지만 등록할 수 있습니다."
      );
      return false;
    }

    if (file.size > 10 * 1024 * 1024) {
      alert("이미지는 10MB 이하만 등록할 수 있습니다.");
      return false;
    }

    return true;
  }

  function handleImageDrop(
    event: React.DragEvent<HTMLDivElement>
  ) {
    event.preventDefault();
    event.stopPropagation();

    setIsDraggingImage(false);

    if (uploadingImage) return;

    const file =
      event.dataTransfer.files?.[0];

    if (!file || !isSupportedImage(file)) {
      return;
    }

    void uploadImage(file);
  }

  function applyBandPostText(
    text: string,
    showMessage = false
  ) {
    const parsed = parseBandPost(text);

    if (!parsed) return false;

    const supplierCode =
      supplierCodeFromProductCode(
        parsed.code
      );

    const matchedSupplier =
      suppliers.find(
        (supplier) =>
          supplier.code
            .trim()
            .toUpperCase() ===
          supplierCode
      );

    setBandPostText(text);

    setForm((current) => ({
      ...current,
      code: parsed.code,
      supplierId: matchedSupplier
        ? String(matchedSupplier.id)
        : current.supplierId,
      sourceProductName:
        parsed.sourceProductName,
      name: parsed.sourceProductName,
      colors:
        parsed.colors || current.colors,
      sizes:
        parsed.sizes || current.sizes,
    }));

    if (showMessage) {
      alert(
        "밴드 게시글에서 상품정보를 자동으로 입력했습니다."
      );
    }

    return true;
  }

  function handleSmartPaste(
    event: React.ClipboardEvent<HTMLFormElement>
  ) {
    if (uploadingImage) return;

    const imageItem = Array.from(
      event.clipboardData.items
    ).find((item) =>
      item.type.startsWith("image/")
    );

    if (imageItem) {
      const file = imageItem.getAsFile();

      if (
        !file ||
        !isSupportedImage(file)
      ) {
        return;
      }

      event.preventDefault();

      void uploadImage(file);

      return;
    }

    const pastedText =
      event.clipboardData.getData(
        "text/plain"
      );

    if (
      !pastedText ||
      !pastedText.includes("\n")
    ) {
      return;
    }

    if (applyBandPostText(pastedText)) {
      event.preventDefault();
    }
  }

  async function uploadImage(
    file: File
  ) {
    if (!isSupportedImage(file)) {
      return;
    }

    try {
      setUploadingImage(true);

      const formData = new FormData();

      formData.append("file", file);

      const response = await fetch(
        "/api/upload/product-image",
        {
          method: "POST",
          body: formData,
        }
      );

      const result =
        await response.json();

      if (!response.ok) {
        alert(
          result.message ||
            "이미지 업로드에 실패했습니다."
        );
        return;
      }

      updateForm(
        "imageUrl",
        result.url
      );
    } catch (error) {
      console.error(error);

      alert(
        "이미지 업로드 중 오류가 발생했습니다."
      );
    } finally {
      setUploadingImage(false);
    }
  }

  async function saveProduct(
    event: React.FormEvent
  ) {
    event.preventDefault();

    if (!form.code.trim()) {
      alert(
        "상품코드를 입력해주세요."
      );
      return;
    }

    if (!form.name.trim()) {
      alert(
        "상품명을 입력해주세요."
      );
      return;
    }

    try {
      setSaving(true);

      let resolvedSupplierId =
        form.supplierId;

      if (!resolvedSupplierId) {
        const supplierCode =
          supplierCodeFromProductCode(
            form.code
          );

        if (supplierCode) {
          resolvedSupplierId =
            await findOrCreateSupplierId(
              supplierCode
            );
        }
      }

      const response = await fetch(
        "/api/product",
        {
          method: editingId
            ? "PUT"
            : "POST",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            id: editingId,
            ...form,
            supplierId:
              resolvedSupplierId,
          }),
        }
      );

      const result =
        await response.json();

      if (!response.ok) {
        alert(
          result.message ||
            (editingId
              ? "상품 수정에 실패했습니다."
              : "상품 등록에 실패했습니다.")
        );
        return;
      }

      alert(
        editingId
          ? "상품이 수정되었습니다."
          : "상품이 등록되었습니다."
      );

      resetForm();
      setShowProductForm(false);

      await loadProducts();
    } catch (error) {
      console.error(error);

      alert(
        "상품 저장 중 오류가 발생했습니다."
      );
    } finally {
      setSaving(false);
    }
  }
    async function deleteProduct(product: Product) {
    const confirmed = window.confirm(
      `${product.code} / ${product.name}\n\n이 상품을 삭제하시겠습니까?`
    );

    if (!confirmed) return;

    try {
      setDeletingId(product.id);

      const response = await fetch(
        `/api/product?id=${product.id}`,
        {
          method: "DELETE",
        }
      );

      const result = await response.json();

      if (!response.ok) {
        alert(
          result.message || "상품 삭제에 실패했습니다."
        );
        return;
      }

      alert(
        result.message || "상품이 삭제되었습니다."
      );

      await loadProducts();
    } catch (error) {
      console.error(error);

      alert("상품 삭제 중 오류가 발생했습니다.");
    } finally {
      setDeletingId(null);
    }
  }

  async function saveInlineProduct(
    product: Product,
    changes: {
      supplierName?: string;
      cost?: string;
      imageUrl?: string;
    }
  ) {
    try {
      setInlineSavingId(product.id);

      let supplierId = product.supplierId;

      if (changes.supplierName !== undefined) {
        const supplierName =
          changes.supplierName.trim();

        if (!supplierName) {
          supplierId = null;
        } else {
          let matchedSupplier =
            suppliers.find(
              (supplier) =>
                supplier.name
                  .trim()
                  .toLowerCase() ===
                  supplierName.toLowerCase() ||
                supplier.code
                  .trim()
                  .toLowerCase() ===
                  supplierName.toLowerCase()
            );

          if (!matchedSupplier) {
            const createResponse =
              await fetch(
                "/api/suppliers",
                {
                  method: "POST",
                  headers: {
                    "Content-Type":
                      "application/json",
                  },
                  body: JSON.stringify({
                    code: supplierName,
                    name: supplierName,
                    businessNumber: "",
                    representative: "",
                    phone: "",
                    email: "",
                    address: "",
                    contactName: "",
                    contactPhone: "",
                    bankName: "",
                    bankAccount: "",
                    accountHolder: "",
                    memo: "",
                  }),
                }
              );

            const createdSupplier =
              await createResponse.json();

            if (!createResponse.ok) {
              throw new Error(
                createdSupplier.message ||
                  "공급업체 저장에 실패했습니다."
              );
            }

            matchedSupplier =
              createdSupplier;

            await loadSuppliers();
          }

          supplierId =
            matchedSupplier?.id ?? null;
        }
      }

      const nextCost =
        changes.cost !== undefined
          ? Number(
              String(changes.cost)
                .replace(/,/g, "")
                .trim() || 0
            )
          : Number(product.cost || 0);

      if (Number.isNaN(nextCost)) {
        throw new Error(
          "단가는 숫자로 입력해주세요."
        );
      }

      const response = await fetch(
        "/api/product",
        {
          method: "PUT",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            id: product.id,
            code: product.code,
            name: product.name,
            brand: product.brand || "",
            category:
              product.category || "",
            colors:
              product.colors || "",
            sizes:
              product.sizes || "",
            cost: nextCost,
            cost2: Number(
              product.cost2 || 0
            ),
            cost3: Number(
              product.cost3 || 0
            ),
            price: Number(
              product.price || 0
            ),
            imageUrl:
              changes.imageUrl !==
              undefined
                ? changes.imageUrl
                : product.imageUrl || "",
            productType:
              product.productType,
            supplierId,
            supplier2Id:
              product.supplier2Id,
            supplier3Id:
              product.supplier3Id,
            sourceProductName:
              product.sourceProductName ||
              "",
            bandPostId:
              product.bandPostId || "",
            bandPostUrl:
              product.bandPostUrl || "",
            isBandImported:
              product.isBandImported,
          }),
        }
      );

      const result =
        await response.json();

      if (!response.ok) {
        throw new Error(
          result.message ||
            "상품 저장에 실패했습니다."
        );
      }

      setInlineSupplierDrafts(
        (current) => {
          const next = { ...current };
          delete next[product.id];
          return next;
        }
      );

      setInlineCostDrafts(
        (current) => {
          const next = { ...current };
          delete next[product.id];
          return next;
        }
      );

      await loadProducts();
    } catch (error) {
      console.error(error);

      alert(
        error instanceof Error
          ? error.message
          : "저장 중 오류가 발생했습니다."
      );

      await loadProducts();
    } finally {
      setInlineSavingId(null);
    }
  }
    async function uploadInlineImage(
    product: Product,
    file: File
  ) {
    if (!isSupportedImage(file)) {
      return;
    }

    try {
      setInlineSavingId(product.id);

      const formData = new FormData();

      formData.append("file", file);

      const uploadResponse = await fetch(
        "/api/upload/product-image",
        {
          method: "POST",
          body: formData,
        }
      );

      const uploadResult =
        await uploadResponse.json();

      if (!uploadResponse.ok) {
        throw new Error(
          uploadResult.message ||
            "이미지 업로드에 실패했습니다."
        );
      }

      await saveInlineProduct(product, {
        imageUrl: uploadResult.url,
      });
    } catch (error) {
      console.error(error);

      alert(
        error instanceof Error
          ? error.message
          : "이미지 업로드 중 오류가 발생했습니다."
      );
    } finally {
      setInlineSavingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold">
            상품관리
          </h1>
          <p className="text-sm text-gray-500">
            상품을 등록하고 관리합니다.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={openCreateForm}
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
          >
            {showProductForm
              ? "등록창 닫기"
              : "상품등록"}
          </button>

          <button
            type="button"
            onClick={downloadProductExcel}
            className="rounded-lg border px-4 py-2 text-sm hover:bg-gray-50"
          >
            엑셀양식
          </button>

          <input
            ref={excelInputRef}
            type="file"
            accept=".xlsx,.xls"
            className="hidden"
            onChange={uploadProductExcel}
          />

          <button
            type="button"
            onClick={() =>
              excelInputRef.current?.click()
            }
            disabled={importingExcel}
            className="rounded-lg border px-4 py-2 text-sm hover:bg-gray-50 disabled:opacity-50"
          >
            {importingExcel
              ? "업로드중..."
              : "엑셀업로드"}
          </button>
        </div>
      </div>

      {showProductForm && (
        <form
          onSubmit={saveProduct}
          onPaste={handleSmartPaste}
          className="rounded-xl border bg-white p-6 shadow-sm"
        >
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-medium">
                상품코드
              </label>

              <input
                value={form.code}
                onChange={(e) =>
                  updateForm(
                    "code",
                    e.target.value
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">
                공급업체
              </label>

              <select
                value={form.supplierId}
                onChange={(e) =>
                  changePrimarySupplier(
                    e.target.value
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              >
                <option value="">
                  선택
                </option>

                {suppliers.map((supplier) => (
                  <option
                    key={supplier.id}
                    value={supplier.id}
                  >
                    {supplier.name}
                  </option>
                ))}
              </select>
            </div>
                        <div>
              <label className="mb-1 block text-sm font-medium">
                원본상품명
              </label>

              <input
                value={form.sourceProductName}
                onChange={(e) =>
                  updateForm(
                    "sourceProductName",
                    e.target.value
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">
                상품명
              </label>

              <input
                value={form.name}
                onChange={(e) =>
                  updateForm(
                    "name",
                    e.target.value
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">
                브랜드
              </label>

              <input
                value={form.brand}
                onChange={(e) =>
                  updateForm(
                    "brand",
                    e.target.value
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">
                카테고리
              </label>

              <input
                value={form.category}
                onChange={(e) =>
                  updateForm(
                    "category",
                    e.target.value
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">
                색상
              </label>

              <input
                value={form.colors}
                onChange={(e) =>
                  updateForm(
                    "colors",
                    e.target.value
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">
                사이즈
              </label>

              <input
                value={form.sizes}
                onChange={(e) =>
                  updateForm(
                    "sizes",
                    e.target.value
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">
                단가
              </label>

              <input
                value={form.cost}
                onChange={(e) =>
                  updateForm(
                    "cost",
                    normalizeOneDecimal(
                      e.target.value
                    )
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium">
                판매가
              </label>

              <input
                value={form.price}
                onChange={(e) =>
                  updateForm(
                    "price",
                    normalizeOneDecimal(
                      e.target.value
                    )
                  )
                }
                className="w-full rounded-lg border px-3 py-2"
              />
            </div>
          </div>

          <div className="mt-6">
            <label className="mb-2 block text-sm font-medium">
              상품 이미지
            </label>

            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDraggingImage(true);
              }}
              onDragLeave={() =>
                setIsDraggingImage(false)
              }
              onDrop={handleImageDrop}
              className={`rounded-xl border-2 border-dashed p-6 transition ${
                isDraggingImage
                  ? "border-blue-500 bg-blue-50"
                  : "border-gray-300"
              }`}
            >
              <div className="flex flex-col items-center gap-3">
                {form.imageUrl ? (
                  <img
                    src={form.imageUrl}
                    alt=""
                    className="max-h-56 rounded-lg border"
                  />
                ) : (
                  <div className="text-sm text-gray-500">
                    이미지를 드래그하거나 Ctrl + V로 붙여넣기
                  </div>
                )}

                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file =
                      e.target.files?.[0];

                    if (file) {
                      void uploadImage(file);
                    }

                    e.target.value = "";
                  }}
                />

                <button
                  type="button"
                  onClick={() =>
                    imageInputRef.current?.click()
                  }
                  disabled={uploadingImage}
                  className="rounded-lg border px-4 py-2 text-sm"
                >
                  {uploadingImage
                    ? "업로드중..."
                    : "이미지 선택"}
                </button>
              </div>
            </div>
          </div>
                    <div className="mt-6">
            <label className="mb-2 block text-sm font-medium">
              밴드 게시글
            </label>

            <textarea
              value={bandPostText}
              onChange={(e) =>
                setBandPostText(e.target.value)
              }
              onBlur={() =>
                applyBandPostText(
                  bandPostText,
                  true
                )
              }
              rows={6}
              className="w-full rounded-lg border px-3 py-2"
            />
          </div>

          <div className="mt-6 flex gap-2">
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-blue-600 px-5 py-2 text-white hover:bg-blue-700 disabled:opacity-50"
            >
              {saving
                ? "저장중..."
                : editingId
                ? "상품수정"
                : "상품등록"}
            </button>

            <button
              type="button"
              onClick={cancelForm}
              className="rounded-lg border px-5 py-2 hover:bg-gray-50"
            >
              취소
            </button>
          </div>
        </form>
      )}

      <div className="rounded-xl border bg-white p-4 shadow-sm">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="flex gap-2">
            <select
              value={searchField}
              onChange={(e) =>
                setSearchField(
                  e.target.value as
                    | "all"
                    | "code"
                    | "name"
                    | "supplier"
                    | "brand"
                    | "category"
                )
              }
              className="rounded-lg border px-3 py-2"
            >
              <option value="all">
                전체
              </option>
              <option value="code">
                상품코드
              </option>
              <option value="name">
                상품명
              </option>
              <option value="supplier">
                공급업체
              </option>
              <option value="brand">
                브랜드
              </option>
              <option value="category">
                카테고리
              </option>
            </select>

            <input
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
              placeholder="검색"
              className="w-64 rounded-lg border px-3 py-2"
            />
          </div>

          <div className="text-sm text-gray-500">
            총 {filteredProducts.length}개
          </div>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="min-w-full border-collapse">
            <thead>
              <tr className="border-b bg-gray-50 text-left">
                <th className="px-3 py-2">
                  이미지
                </th>
                <th className="px-3 py-2">
                  상품코드
                </th>
                <th className="px-3 py-2">
                  상품명
                </th>
                <th className="px-3 py-2">
                  공급업체
                </th>
                <th className="px-3 py-2">
                  단가
                </th>
                <th className="px-3 py-2">
                  판매가
                </th>
                <th className="px-3 py-2">
                  관리
                </th>
              </tr>
            </thead>

            <tbody>
                            {filteredProducts.map(
                (product) => (
                  <tr
                    key={product.id}
                    className="border-b"
                  >
                    <td className="px-3 py-2">
                      <div className="flex items-center gap-2">
                        {product.imageUrl ? (
                          <img
                            src={product.imageUrl}
                            alt={product.name}
                            className="h-14 w-14 rounded border object-cover"
                          />
                        ) : (
                          <div className="flex h-14 w-14 items-center justify-center rounded border text-xs text-gray-400">
                            없음
                          </div>
                        )}

                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          id={`image-${product.id}`}
                          onChange={(e) => {
                            const file =
                              e.target.files?.[0];

                            if (file) {
                              void uploadInlineImage(
                                product,
                                file
                              );
                            }

                            e.target.value = "";
                          }}
                        />

                        <label
                          htmlFor={`image-${product.id}`}
                          className="cursor-pointer rounded border px-2 py-1 text-xs hover:bg-gray-50"
                        >
                          변경
                        </label>
                      </div>
                    </td>

                    <td className="px-3 py-2 whitespace-nowrap">
                      {product.code}
                    </td>

                    <td className="px-3 py-2">
                      <div className="font-medium">
                        {product.name}
                      </div>

                      {product.sourceProductName && (
                        <div className="text-xs text-gray-500">
                          {product.sourceProductName}
                        </div>
                      )}
                    </td>

                    <td className="px-3 py-2">
                      <input
                        value={
                          inlineSupplierDrafts[
                            product.id
                          ] ??
                          product.supplier?.name ??
                          ""
                        }
                        onChange={(e) =>
                          setInlineSupplierDrafts(
                            (current) => ({
                              ...current,
                              [product.id]:
                                e.target.value,
                            })
                          )
                        }
                        onBlur={() =>
                          void saveInlineProduct(
                            product,
                            {
                              supplierName:
                                inlineSupplierDrafts[
                                  product.id
                                ] ??
                                product.supplier
                                  ?.name ??
                                "",
                            }
                          )
                        }
                        className="w-40 rounded border px-2 py-1"
                      />
                    </td>

                    <td className="px-3 py-2">
                      <input
                        value={
                          inlineCostDrafts[
                            product.id
                          ] ??
                          String(
                            product.cost ?? ""
                          )
                        }
                        onChange={(e) =>
                          setInlineCostDrafts(
                            (current) => ({
                              ...current,
                              [product.id]:
                                e.target.value,
                            })
                          )
                        }
                        onBlur={() =>
                          void saveInlineProduct(
                            product,
                            {
                              cost:
                                inlineCostDrafts[
                                  product.id
                                ] ??
                                String(
                                  product.cost ??
                                    ""
                                ),
                            }
                          )
                        }
                        className="w-24 rounded border px-2 py-1 text-right"
                      />
                    </td>

                    <td className="px-3 py-2 text-right">
                      {product.price
                        ? Number(
                            product.price
                          ).toLocaleString()
                        : "-"}
                    </td>

                    <td className="px-3 py-2">
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            startEdit(product)
                          }
                          className="rounded border px-2 py-1 text-xs hover:bg-gray-50"
                        >
                          수정
                        </button>

                        {isAdmin && (
                          <button
                            type="button"
                            disabled={
                              deletingId ===
                              product.id
                            }
                            onClick={() =>
                              void deleteProduct(
                                product
                              )
                            }
                            className="rounded border border-red-300 px-2 py-1 text-xs text-red-600 hover:bg-red-50 disabled:opacity-50"
                          >
                            삭제
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                )
              )}
                          </tbody>
          </table>

          {filteredProducts.length === 0 && (
            <div className="py-10 text-center text-sm text-gray-500">
              등록된 상품이 없습니다.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}